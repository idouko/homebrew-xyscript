#-*- encoding:utf-8 -*-
name = "xyscript"
