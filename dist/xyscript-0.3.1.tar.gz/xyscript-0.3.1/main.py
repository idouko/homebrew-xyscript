# -*- coding: utf-8 -*-
import sys
from xyscript.config import Config
from setup import setup as st
def main():
    print("进入入口主程序")
    pass

def test():
    pass

if __name__ == '__main__':
    main()
    print(st)
    # print(Config().get_version())
