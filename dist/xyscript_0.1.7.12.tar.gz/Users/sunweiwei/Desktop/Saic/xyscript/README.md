##  脚本管理工具xyscript使用方法

###  Install:

查看pip是否安装

```$ pip --version```

下载pip安装脚本，已安装则跳过

```$ curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py```

运行安装脚本，已安装则跳过

```$ sudo python get-pip.py```

安装xyscript

```$ sudo pip install xyscript==0.1.7.2```
或者 
```$ sudo pip3 install xyscript==0.1.7.2```

如果已经安装过，更新即可

```$ sudo pip install -U xyscript```
或者 
```$ sudo pip3 install -U xyscript```


###  Actions:
####  -h or -help （帮助文档)
```$ xyscript -h or $ xyscript -help```

####  -v or -version （查看版本号)
```$ xyscript -v or $ xyscript -version```

####  pullsubmodule (拉取子模块)

类似Podfile，当前目录需要存在`projconfig.json`文件，来配置需要拉取的子模块的路径和分支，例如：
```json
[
    {
        "module":"submodules/module-login",
        "branch":"develop"
    },
    {
        "module":"submodules/module-account",
        "branch":"master"
    }
]
```
执行`$ xyscript pullsubmodule`拉取依赖的子模块分支

####  syn (拉取最新证书)
```$ xyscript syn```

####  pps (管理员reset证书和描述文件，正常情况下使用上述syn方法即可)
```$ xyscript pps```

####  package  (自动打包)
```$ xyscript package -a [address_name] -b [branch_name] -p [platform] -e [net_env] -n [version] -d [build]```

:eg. 
```
$ xyscript package -a https://github.com/XXXX -p pgyer -b Develop -e dev//蒲公英
```
or
```
$ xyscript package -a https://github.com/XXXX -p testflight -b master -e release -n 1.1 -d 2//TestFlight
```

###  History
``` bash
0.1.6
    add -n -d to package function
0.1.5
    ...
0.1.4
    ...
0.1.3
    Optimize code logic
0.1.2
    Fix failed problems for pod install
0.1.1
    Add choose to network environment
0.1.0
    Complete deployment testing
0.0.8
    Add packaging to pgyer、testflight
0.0.7
    Test
0.0.6
    Add syn action to pull latest certs
0.0.5
    Add change_branch to pullsubmodule
    Add run_pod_install to pullsubmodule
0.0.4
    Optimize the code
0.0.3
    ...
0.0.2
    ...
0.0.1 
    Initial project
    Provides the ability to pull submodules  
```      
