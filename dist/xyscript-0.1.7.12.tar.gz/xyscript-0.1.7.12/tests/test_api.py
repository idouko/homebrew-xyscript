import xyscript.api
import xyscript.package
import time

# xyscript.api.syn()
# xyscript.api.pullsubmodule()
print(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))