#!/usr/bin/env python
# coding=utf-8
#-*- encoding:utf-8 -*-
# from __future__ import print_function

from xyscript.CommonScript import GitLabTool

GitLabTool().change_branch_g("Develop")

def main():
    GitLabTool().change_branch_g("Develop")

if __name__ == "__main_":
    main()