from xyscript.api import main

# python -m xyscript
if __name__ == '__main__':
    main(prog='xyscript')