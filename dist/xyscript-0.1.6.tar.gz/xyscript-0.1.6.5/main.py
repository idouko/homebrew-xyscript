# -*- coding: utf-8 -*-
import sys
def main():
    print("进入入口主程序")
    pass

def test():
    pass

if __name__ == '__main__':
    main()